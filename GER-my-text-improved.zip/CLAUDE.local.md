# Personal notes (not committed)

Git-ignored — Claude Code loads this alongside `CLAUDE.md`, but nothing
here is shared with the rest of the team. Good candidates:

- Local dev quirks (a port you always change, a sandbox URL, a test
  account you use)
- Personal shorthand instructions (e.g. "when I say 'ship it', run
  typecheck + lint + test + build, then stop")
- Scratch context for whatever you're mid-way through right now
- Any preference you don't want to impose on teammates via the shared
  `.claude/settings.json`

Nothing is filled in yet — this is a starting template. Make sure
`CLAUDE.local.md` and `.claude/settings.local.json` are in `.gitignore`
(Claude Code adds the second one automatically the first time it writes to
it; this file needs adding by hand).
